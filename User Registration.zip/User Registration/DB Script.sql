CREATE PROC UserAddOrEdit
@UserID int,
@FirstName varchar(50),
@LastName Varchar(50),
@PersonalPhoto image,
@Email varchar(50),
@Phone varchar(50),
@Gender varchar(10),
@Documents image,
@Password varchar(50)

AS 
	IF @UserID = 0
	BEGIN
		INSERT INTO UserRegistration (FirstName,LastName,PersonalPhoto,Email,Phone,Gender,Documents,Password)
		VALUES (@FirstName,@LastName,@PersonalPhoto,@Email,@Phone,@Gender,@Documents,@Password)
	END
	ELSE
	BEGIN
		UPDATE UserRegistration
		SET
			FirstName = @FirstName,
			LastName = @LastName,
			PersonalPhoto = @PersonalPhoto,
			Email = @Email,
			Phone = @Phone,
			Gender = @Gender,
			Documents = @Documents,
			Password = @Password
			
			
		WHERE UserID = @UserID
	END
			

