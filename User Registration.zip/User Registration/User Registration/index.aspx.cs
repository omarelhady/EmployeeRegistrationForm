﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace User_Registration
{
    public partial class index : System.Web.UI.Page
    {
        string connectionString = @"Data Source=LENOVO-PC\OMAR;Initial Catalog=UserRegistrationDB;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Clear();
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)

        {
            if (txtFirstName.Text == "" || txtPassword.Text == "")
                lblErrorMessage.Text = "Please fill empty fields!";
            else if (txtPassword.Text != txtConfirmPassword.Text)
                lblErrorMessage.Text = "Passwords doesn't match!";
            else
            {


                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("UserAddOrEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@UserID", Convert.ToInt32(hfUserID.Value == "" ? "0" : hfUserID.Value));
                    sqlCmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@LastName", txtLastName.Text.Trim());
                    //sqlCmd.Parameters.AddWithValue("@PersonalPhoto", FUPersonalPhoto());
                    sqlCmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Phone", txtPhone.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Gender", ddlGender.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@Documents", FUDocuments);
                    sqlCmd.Parameters.AddWithValue("@Password", txtFirstName.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    Clear();
                    lblSuccessMessage.Text = "Registered Successfully";
                }
            }

        }

        void Clear()
        {
            txtFirstName.Text = txtLastName.Text = txtEmail.Text = txtPhone.Text = txtPassword.Text = txtConfirmPassword.Text;
            hfUserID.Value = "";
            lblSuccessMessage.Text = lblErrorMessage.Text = "";

        }

        
    }
}